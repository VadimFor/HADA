﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using library.EN;

namespace library.CAD
{
    class CAD_Contrato
    {
        public bool leer_Contrato(EN_Contrato en)
        {

        }

        public bool borrar_Contrato(EN_Contrato en)
        {

        }
    }
}
