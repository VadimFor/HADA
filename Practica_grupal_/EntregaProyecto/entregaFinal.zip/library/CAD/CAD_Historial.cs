﻿using library.EN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library.CAD
{
    class CAD_Historial
    {
        public bool leer_Historial(EN_Historial en)
        {
            return false;
        }
        
        public bool borrar_Historial(EN_Historial en)
        {
            return false;
        }
    }
}
